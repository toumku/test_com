import { DevicesScreen } from '@/screens/devices.screen';

export default function DevicesPage() {
  return <DevicesScreen />;
}
