import { UsersScreen } from '@/screens/users.screen';

export default function UsersPage() {
  return <UsersScreen />;
}
