import { EmployeesScreen } from '@/screens/employees.screen';

export default function EmployeesPage() {
  return <EmployeesScreen />;
}
